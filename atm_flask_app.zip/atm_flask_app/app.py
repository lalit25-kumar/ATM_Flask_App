from flask import Flask, render_template, request, redirect, url_for, session

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

# Sample user data
users = {
    "lalit kumar": {
        "pin": "5395",
        "balance": 1000
    }
}

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        pin = request.form['pin']
        user = users.get(username)

        if user and user['pin'] == pin:
            session['username'] = username
            return redirect(url_for('dashboard'))
        else:
            error = "Invalid username or PIN"
            return render_template('login.html', error=error)
    return render_template('login.html')


@app.route('/dashboard')
def dashboard():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    username = session['username']
    user = users[username]
    return render_template('dashboard.html', username=username, balance=user['balance'], message='')

@app.route('/deposit', methods=['POST'])
def deposit():
    if 'username' not in session:
        return redirect(url_for('login'))

    username = session['username']
    user = users[username]
    amount = float(request.form['amount'])
    user['balance'] += amount
    message = f"₹{amount} deposited successfully."
    return render_template('dashboard.html', username=username, balance=user['balance'], message=message)

@app.route('/withdraw', methods=['POST'])
def withdraw():
    if 'username' not in session:
        return redirect(url_for('login'))

    username = session['username']
    user = users[username]
    amount = float(request.form['amount'])
    if amount > user['balance']:
        message = "Insufficient balance."
    else:
        user['balance'] -= amount
        message = f"₹{amount} withdrawn successfully."
    return render_template('dashboard.html', username=username, balance=user['balance'], message=message)

@app.route('/logout', methods=['POST'])
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))


if __name__ == "__main__":
    app.run(debug=True)
